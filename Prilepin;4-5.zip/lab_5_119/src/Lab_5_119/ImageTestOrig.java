package Lab_5_119;

import javax.swing.*;
import java.awt.*;

public class ImageTestOrig extends JFrame {
    static String str ="";
    static int m;
    JPanel panel = new JPanel();
    ImageTestOrig(String str) {
        super("Test1");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(new BorderLayout());
        JLabel label = new JLabel(new ImageIcon(str));
        add(panel);
        panel.add(label);
        pack();
    }
    public static void main(String[] args) {
        for (m = 0; m < args.length; m++) {
            str+=args[m];
        }
        ImageTestOrig it = new ImageTestOrig(str);
        it.setVisible(true);
        it.setLocationRelativeTo(null);
    }
}
