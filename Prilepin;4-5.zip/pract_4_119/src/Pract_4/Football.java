package Pract_4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Football extends JFrame {

    int Mil=0, Mad=0;
    JButton butMilan = new JButton("AC Milan");
    JButton butMadrid = new JButton("Real Madrid");
    JLabel Rst = new JLabel("Result: " + Mil + " X " + Mad);
    JLabel Lst = new JLabel("Last Scorer: N/A");
    JLabel Win = new JLabel("Winner: DRAW");
    JPanel panel = new JPanel();

    private void createGUI() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panel);
        setSize(370, 120);
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        panel.setBackground(new Color(50,100,150));
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
            hGroup.addComponent(butMilan)
                    .addGroup (layout.createParallelGroup ()
                          .addComponent (Rst)
                          .addComponent (Lst)
                          .addComponent(Win))
                    .addComponent(butMadrid);
        layout.setHorizontalGroup (hGroup);
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup ();
        vGroup.addGroup (layout.createParallelGroup ()
                .addComponent (butMilan)
                .addGroup (layout.createSequentialGroup()
                        .addComponent(Rst)
                        .addComponent(Lst)
                        .addComponent(Win))
                .addComponent(butMadrid));
        layout.setVerticalGroup (vGroup);
        pack();
        butMilan.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent a)
            {
                Mil++;
                Rst.setText("Result: " + Mil + " X " + Mad);
                Lst.setText("Last Scorer: AC Milan");
                if(Mil > Mad)
                    Win.setText("Winner: AC Milan");
                else if(Mil == Mad)
                    Win.setText("Winner: DRAW");
                pack();
            }
        });
        butMadrid.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent a)
            {
                Mad++;
                Rst.setText("Result: "+ Mil +" X " + Mad);
                Lst.setText("Last Scorer: Real Madrid");
                if(Mil < Mad)
                    Win.setText("Winner: Real Madrid");
                else if(Mil == Mad)
                    Win.setText("Winner: DRAW");
                pack();
            }
        });
    }

    public Football() {
        super("Football");
        createGUI();
    }

    public static void main(String[] args) {
        JFrame.setDefaultLookAndFeelDecorated(true);
        Football ft = new Football();
        ft.setVisible(true);
        ft.setLocationRelativeTo(null);
    } 
}
