package Pract_5_119;

import java.util.Scanner;

public class Solution13 {
    public static void recursion() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if (n > 0) {
            System.out.println(n);
            int m = sc.nextInt();
            if (m > 0) {
                recursion();
            }
        }
    }
    public static void main(String[] args) {
        recursion();
    }
}