package Lab_1_119;

import java.util.ArrayList;
import java.util.Scanner;

public class Task1 {

    private int n, i;
    private double sum;
    Scanner sc = new Scanner(System.in);
    ArrayList <Double> array = new ArrayList<>(n);

    public Task1() {
        System.out.println("Введите размер массива");
        n = sc.nextInt();
        System.out.println("Заполните массив");
        for (i=0;i<n;i++) {
            array.add(i,sc.nextDouble());
        }
    }

    public double getSumFor(){
        for (i=0;i<n;i++) {
            sum+=array.get(i);
        }
        return sum;
    }

    public double getSumWhile(){
        i=0;
        while (i<n) {
            sum+=array.get(i);
            i+=1;
        }
        return sum;
    }

    public double getSumDoWhile(){
        i=0;
        do {
            sum+=array.get(i);
            i+=1;
        } while (i<n);
        return sum;
    }

}
