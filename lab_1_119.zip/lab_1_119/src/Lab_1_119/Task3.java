package Lab_1_119;

public class Task3 {

    private int i;
    private double num;

    public Task3() {
        System.out.print("Первые 10 чисел гармонического ряда: ");
        for (i=1;i<=10;i++) {
            num = 1.0/i;
            System.out.println(num + " ");
        }
    }

}
