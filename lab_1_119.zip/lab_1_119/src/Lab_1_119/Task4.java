package Lab_1_119;

public class Task4 {

    private int i, j;
    private int[] array = new int[10];

    public Task4() {
        System.out.print("Массив сгенерирован: ");
        for (i = 0; i < 10; i++) {
            array[i] = (int) (Math.random() * 101);
            System.out.print(array[i] + " ");
        }
        System.out.println();
        System.out.println("Элементы массива сортируются...");
    }

    public void normArray() {
        for (i = 0; i<10;i++){
            for(j = 0; j<9; j++){
                if (array[j] > array[j+1]){
                    int gg = array[j+1];
                    array[j+1] = array[j];
                    array[j] = gg;
                }
            }
        }
        System.out.print("Массив отсортирован: ");
        for (i = 0; i<10; i++){
            System.out.print(array[i] + " ");
        }
    }

}
