package Lab_1_119;

import java.util.Scanner;

public class Task5 {
    private  int i, l, fct = 1;
    private Scanner sc = new Scanner(System.in);

    public Task5() {
        System.out.println("Введите число, факториал которого вы хотите найти");
        l = sc.nextInt();
    }
    public void getFactorial() {
        for (i = 1; i <= l; i++) {
            fct = fct * i;
        }
        System.out.println("Факсториал " + l + " = " + fct);
    }
}
