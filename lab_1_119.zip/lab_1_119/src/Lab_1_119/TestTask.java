package Lab_1_119;

import java.util.Scanner;

public class TestTask {

    private static int s, m;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Введите номер задания (1-5)");
        do {
            s = sc.nextInt();
            switch (s) {
                case 1:
                    Task1 tk1 = new Task1();
                    System.out.println("Введите номер цикла: 1 - for, 2 - while, 3 do while");
                    m = sc.nextInt();
                    switch (m) {
                        case 1:
                            System.out.println("Сумма = " + tk1.getSumFor());
                            break;
                        case 2:
                            System.out.println("Сумма = " + tk1.getSumWhile());
                            break;
                        case 3:
                            System.out.println("Сумма = " + tk1.getSumDoWhile());
                            break;
                    }
                    break;
                case 2:
                    System.out.print("Аргументы командной строки: ");
                    for (m = 0; m < args.length; m++) {
                        System.out.print(args[m] + " ");
                    }
                    break;
                case 3:
                    Task3 tk3 = new Task3();
                    break;
                case 4:
                    Task4 tk4 = new Task4();
                    tk4.normArray();
                    break;
                case 5:
                    Task5 tk5 = new Task5();
                    tk5.getFactorial();
                    break;
            }
        } while (s!=0);
    }

}
