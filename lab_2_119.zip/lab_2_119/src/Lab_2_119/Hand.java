package Lab_2_119;

public class Hand {

        private char brush_size;

        public Hand(char brush_size) {
            this.brush_size = brush_size;
        }

        public int getBrush_size() {
            return brush_size;
        }

        public void setBrush_size(char brush_size) {
            this.brush_size = brush_size;
        }

}
