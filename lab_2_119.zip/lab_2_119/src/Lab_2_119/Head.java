package Lab_2_119;

public class Head {

    private String colorHair;
    private String colorEyes;

    public Head(String colorHair, String colorEyes) {
        this.colorHair = colorHair;
        this.colorEyes = colorEyes;
    }

    public String getColorHair() {
        return colorHair;
    }

    public void setColorHair(String colorHair) {
        this.colorHair = colorHair;
    }

    public String getColorEyes() {
        return colorEyes;
    }

    public void setColorEyes(String colorEyes) {
        this.colorEyes = colorEyes;
    }

}
