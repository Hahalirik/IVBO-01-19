package Lab_2_119;

public class Human {

    private String name;
    private int age;
    public Head hd = new Head("red", "blue");
    public Hand hnd = new Hand('M');
    public Leg lg = new Leg(38);

    public Human(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String toString() {
        return this.name + ", " + this.age + " year old " + "\n Color hair - " + hd.getColorHair() + ", color eyes - " + hd.getColorEyes() + "\n Foot size - " + lg.getFoot_size() + ", brush foot - " + hnd.getBrush_size();
    }

}
