package Lab_2_119;

public class Leg {

    private int foot_size;

    public Leg(int foot_size) {
        this.foot_size = foot_size;
    }

    public int getFoot_size() {
        return foot_size;
    }

    public void setFoot_size(int foot_size) {
        this.foot_size = foot_size;
    }

}
