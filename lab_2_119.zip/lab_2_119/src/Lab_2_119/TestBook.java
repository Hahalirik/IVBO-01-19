package Lab_2_119;

public class TestBook {

    public static void main(String[] args) {
        Book bk1 = new Book("Scarlet Sails", "Alexander Grin", 1923);
        System.out.println(bk1);
        bk1.setTitle("Nineteen Eighty-Four");
        bk1.setAuthor("George Orwell");
        bk1.setYear(1949);
        System.out.println(bk1);
    }

}
