package Lab_2_119;

public class TestCircle {

    public static void main(String[] args) {
        Circle cl1 = new Circle(30.1, "red");
        System.out.println(cl1);
        cl1.setRadius(55.2);
        cl1.setColor("green");
        System.out.println(cl1);
    }

}
