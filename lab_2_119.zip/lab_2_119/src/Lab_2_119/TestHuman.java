package Lab_2_119;

public class TestHuman {

    public static void main(String[] args) {
            Human hn = new Human("Masha", 19);
            System.out.println(hn);
            hn.setName("Lina");
            hn.setAge(19);
            System.out.println(hn);
    }

}
