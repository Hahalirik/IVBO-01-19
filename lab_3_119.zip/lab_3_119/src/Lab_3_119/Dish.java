package Lab_3_119;

public abstract class Dish {

    protected String material;
    protected String color;
    protected double price;

    public Dish(String material, String color, double price) {
        this.material = material;
        this.color = color;
        this.price = price;
    }

    public String getMaterial() {
        return material;
    }

    public String getColor() {
        return color;
    }

    public double getPrice() {
        return price;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public abstract String getPurchaseAddress(String add);

    public abstract String getYear(int year);

    public abstract double getVolume(char volume);

    public abstract String toString();

}
