package Lab_3_119;

public class Pan extends Dish{

    protected char volume;

    public Pan(char volume, String material, String color, double price) {
        super(material, color, price);
        this.volume = volume;
    }

    public String getPurchaseAddress(String add){
        return "The pan was purchased at the address " + add + ".";
    }

    public String getYear(int year){
        return "The pan was purchased in " + year + ".";
    }

    public double getVolume(char volume){
        if (volume=='L') return 7.0;
        else if (volume=='M') return 3.5;
        else if (volume=='S') return 1.2;
        else return 0;
    }

    public String toString(){
        return "Pan Information:\nColor: " + this.color + "\nMaterial: " + this.material + "\nPrice: " + this.price + "Volume :" + this.getVolume(this.volume) + '\n' + this.getPurchaseAddress("Bolshoy Ovchinnikovskiy per., 16, 1st floor") + '\n' + this.getYear(2012);
    }

}
