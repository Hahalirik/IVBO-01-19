package Lab_3_119;

public class Plate extends Dish{

    protected char volume;

    public Plate(char volume, String material, String color, double price) {
        super(material, color, price);
        this.volume = volume;
    }

    public String getPurchaseAddress(String add){
        return "The plate was purchased at the address " + add + ".";
    }

    public String getYear(int year){
        return "The plate was purchased in " + year + ".";
    }

    public double getVolume(char volume){
        if (volume=='L') return 700;
        else if (volume=='M') return 500;
        else if (volume=='S') return 250;
        else return 0;
    }

    public String toString(){
        return "Plate Information:\nColor: " + this.color + "\nMaterial: " + this.material + "\nPrice: " + this.price + "Volume :" + this.getVolume(this.volume) + '\n' + this.getPurchaseAddress("Verkhnyaya Krasnoselskaya st., 3A, 2nd floor") + '\n' + this.getYear(2019);
    }

}
