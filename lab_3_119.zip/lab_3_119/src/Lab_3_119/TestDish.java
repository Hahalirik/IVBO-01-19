package Lab_3_119;

public class TestDish {

    public static void main(String[] args) {
        Dish pn = new Pan('M', "Stainless steel", "red", 950);
        Dish plt = new Plate('S', "Porcelain", "blue", 150);
        System.out.println(pn);
        System.out.println(plt);
    }

}
