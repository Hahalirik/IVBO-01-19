package Lab_4_119;

public class Car implements Nameable {

    private String name;

    public Car(String brand, String model, int year) {
        name = "Сar brand - " + brand + ", model -" + model + ", year of manufacture - " + year;
    }

    public String getName(){
        return name;
    }

    public void outInfo(){
        System.out.printf(this.getName());
    }

}
