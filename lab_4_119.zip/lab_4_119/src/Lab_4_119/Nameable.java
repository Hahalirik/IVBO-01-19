package Lab_4_119;

public interface Nameable {

    String getName();

}
