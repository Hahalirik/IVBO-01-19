package Lab_4_119;

public class Planet implements Nameable {

    private String name;

    public Planet(String name, String myth_country, int number) {
        this.name = "Planet " + name + ", mythology " + myth_country + ", serial number" + number;
    }

    public String getName(){
        return name;
    }

    public void outInfo(){
        System.out.printf(this.getName());
    }
}
