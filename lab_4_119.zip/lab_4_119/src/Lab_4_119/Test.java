package Lab_4_119;

import java.util.Scanner;

public class Test {

    public static Nameable createNameable(int x){
        if (x==0) return new Car("Mazda", "X3", 2009);
        else return new Planet("Venus", "Room", 2);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        if (x==0){
            Car cr1 = new Car("Mazda", "X3", 2009);
            cr1.outInfo();
        }
        else {
            Planet pl1 = new Planet("Venus", "Room", 2);
            pl1.outInfo();
        }

    }

}
