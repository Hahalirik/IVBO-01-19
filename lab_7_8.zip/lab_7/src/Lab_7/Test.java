package Lab_7;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        ArrayList<String> planes = new ArrayList<String>(3);
        planes.add("Винтовка Мосина");
        planes.add("Mauser 98");
        planes.add("Steyr Mannlicher M1895");
        for (int i = 0; i < 3; i++){
            System.out.println(planes.get(i));
        }
        System.out.print("Замена: ");
        planes.set(2, "Krag-Jørgensen");
        System.out.println(planes.get(2));
        planes.remove(0);
        System.out.println("Проверка на наличие...");
        System.out.println("Количество винтовок: " + planes.size() + ".");
        if (planes.contains("Винтовка Мосина")){
            System.out.println("У нас есть Винтовка Мосина.");
        }
        else System.out.println("Винтовка Мосина отсутствует на складе.");
        Object[] plane = planes.toArray();
        for (Object pl : plane){
            System.out.print(pl + "\n");
        }
    }
}
