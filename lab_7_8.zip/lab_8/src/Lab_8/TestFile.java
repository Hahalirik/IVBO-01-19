package Lab_8;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class TestFile {

    public static void main(String[] args) throws IOException {
        int c;
        String s;
        Scanner sc = new Scanner(System.in);
        FileWriter wrt2 = new FileWriter("notes3.txt", true);
        s = sc.nextLine();
        wrt2.write(s);
        wrt2.flush();
        wrt2.close();
        FileReader rdr = new FileReader("notes3.txt");
        while ((c = rdr.read()) != -1) {
            System.out.print((char) c);
        }
        rdr.close();
    }
}