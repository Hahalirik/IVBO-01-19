package Pract_1_119;

import java.util.Scanner;

public class Ball {

    private double radius;
    private String color;
    Scanner sc = new Scanner(System.in);

    public Ball() {
        radius = sc.nextDouble();
        color = sc.nextLine();
    }

    public double getRadius() {
        return radius;
    }

    public String getColor() {
        return color;
    }

    public double getVolume() {
        return (4/3)*Math.pow(radius, 3)*Math.PI;
    }

}
