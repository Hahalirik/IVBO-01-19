package Pract_1_119;

public class TestBall {
    public void toString(Ball bl) {
        System.out.println("Radius is " + bl.getRadius() + ", color is " + bl.getColor() + ", volume is " + bl.getVolume());
    }
    public static void main(String[] args) {
        TestBall chek = new TestBall();
        Ball bl = new Ball();
        chek.toString(bl);
    }
}

