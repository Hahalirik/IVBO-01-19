package Pract_2_119;

public class TestAuthor {

    public static void main(String[] args) {
        Author ath = new Author("Cold Anastasia", "CldNastya@mail.ru", 'F');
        System.out.println(ath);
        ath.setEmail("naCsLtyaD@gmail.com");
        System.out.println(ath);
    }

}
