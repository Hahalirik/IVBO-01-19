package Pract_2_119;

public class TestBall {

    public static void main(String[] args) {
        Ball b1 = new Ball(94, 31);
        System.out.println(b1);
        b1.move(55, 44);
        System.out.println(b1);
    }

}
