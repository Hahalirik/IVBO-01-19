package Pract_3_119;

public class Circle extends Shape{

    protected double radius;

    public Circle() {
        radius = 3.15;
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI*(int)Math.pow(radius, 2);
    }

    public double getPerimeter() {
        return 2*Math.PI*radius;
    }

    public String toString() {
        return ("A " + this.color + " circle with a radius of " + this.radius + ", an area of " + this.getArea() + ", a perimeter of " + this.getPerimeter() + ".");
    }
}
