package Pract_3_119;

public class Square extends Rectangle{

    public Square() {
    }

    public Square(double side) {
        width = side;
        length = side;
    }

    public Square(double side, String color, boolean filled) {
        this.setColor(color);
        this.setFilled(filled);
        this.width = side;
        this.length = side;
    }

    public double getSide() {
        return width;
    }

    public void setSide(double side) {
        width = length = side;
    }

    public void setWidth(double side) {
        width = side;
    }

    public void setLength(double side) {
        length = side;
    }

    public String toString() {
        return ("A " + this.color + " rectangle with a side of " + this.width + ".");
    }

}
