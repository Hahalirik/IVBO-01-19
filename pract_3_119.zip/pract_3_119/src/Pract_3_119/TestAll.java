package Pract_3_119;

public class TestAll {

    public static void main(String[] args) {
        Shape crl = new  Circle(5.5, "green", true);
        Shape rct = new Rectangle(4, 5.5, "blue", true);
        Rectangle sqr = new Square(5.2, "yellow", false);
        System.out.println(crl + "\n" + rct + "\n" + sqr);
    }

}
